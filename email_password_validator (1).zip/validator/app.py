from flask import Flask, render_template, request, jsonify
from dfa import EmailDFA, PasswordDFA

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/validate", methods=["POST"])
def validate():
    data = request.get_json(force=True)
    email, password = data.get("email", ""), data.get("password", "")
    e_ok, e_msg, e_path = EmailDFA().run(email)
    p_ok, p_msg, p_path = PasswordDFA().run(password)
    return jsonify(email={"ok": e_ok, "msg": e_msg, "path": e_path},
                   password={"ok": p_ok, "msg": p_msg, "path": p_path})


if __name__ == "__main__":
    app.run(debug=True)          # http://127.0.0.1:5000
