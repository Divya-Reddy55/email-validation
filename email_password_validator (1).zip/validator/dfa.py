"""DFA engines for the Email & Password Validator (Automata Theory & Compiler Design)."""
import string

# ---------------------------------------------------------------- EMAIL DFA
# Language:  <local-part> @ <DOMAIN>
# local-part = one or more of letters, digits, '.', '_', '-', '+'
DOMAIN = "ashoka.edu.in"          # <-- change to your college domain
LOCAL_CHARS = set(string.ascii_letters + string.digits + "._-+")


class EmailDFA:
    """q0 --local--> q1 (loop) --@--> q2 --domain chars--> q3..qN (accepting) ; qd = dead."""

    def __init__(self, domain=DOMAIN):
        self.domain = domain.lower()
        self.final = 2 + len(self.domain)          # index of the accepting state

    def run(self, text):
        state, path = 0, ["q0"]
        for ch in text:
            state = self._delta(state, ch)
            path.append("qd" if state is None else f"q{state}")
            if state is None:
                break
        ok = state == self.final
        if ok:
            msg = "Valid Ashoka College email address."
        elif state is None:
            msg = f"Invalid email. Must look like name@{self.domain}"
        else:
            msg = f"Incomplete email. Must end with @{self.domain}"
        return ok, msg, path

    def _delta(self, s, ch):
        if s is None:
            return None
        if s == 0:
            return 1 if ch in LOCAL_CHARS else None
        if s == 1:
            if ch in LOCAL_CHARS:
                return 1
            return 2 if ch == "@" else None
        if s >= 2 and s < self.final:                # matching the domain literally
            return s + 1 if ch.lower() == self.domain[s - 2] else None
        return None                                   # nothing allowed after accept


# ------------------------------------------------------------- PASSWORD DFA
# State = (length capped at MIN_LEN, has_upper, has_lower, has_digit, has_special)
# Accepting state: length >= 8 and all four flags set.
MIN_LEN = 8
SPECIALS = set("!@#$%^&*()-_=+[]{};:,.<>?/|~")


class PasswordDFA:
    def __init__(self):
        self.names = {}                               # state tuple -> "qN"

    def _name(self, st):
        return self.names.setdefault(st, f"q{len(self.names)}")

    @staticmethod
    def _delta(st, ch):
        n, u, l, d, s = st
        n = min(n + 1, MIN_LEN)
        if ch.isupper():
            u = 1
        elif ch.islower():
            l = 1
        elif ch.isdigit():
            d = 1
        elif ch in SPECIALS:
            s = 1
        return (n, u, l, d, s)

    def run(self, text):
        self.names = {}
        st = (0, 0, 0, 0, 0)
        path = [self._name(st)]
        for ch in text:
            st = self._delta(st, ch)
            path.append(self._name(st))
        n, u, l, d, s = st
        missing = []
        if n < MIN_LEN:
            missing.append(f"at least {MIN_LEN} characters")
        if not u: missing.append("an uppercase letter")
        if not l: missing.append("a lowercase letter")
        if not d: missing.append("a digit")
        if not s: missing.append("a special character")
        ok = not missing
        msg = "Strong password." if ok else "Weak password. Add " + ", ".join(missing) + "."
        return ok, msg, path
